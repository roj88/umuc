/*
 * filename: Node.java
 * author: roland carter
 * date: 2018-11-17
 * purpuse: project 2 cmsc 250
*/

package postfix;

// begin interface Node
public interface Node {
    String inWalk();
    String postWalk();
    void post() ;
}
